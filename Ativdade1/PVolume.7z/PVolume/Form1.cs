﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;



        public Form1()
        {
            InitializeComponent();
        }



        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("Raio Invalido");
            }
            //else if (raio <=0)
            //{
            //  MessageBox.Show("O raio deve ser maior que Zero");
            //}


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();    
        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            textAltura.Text = String.Empty ;
            textVolume.Clear() ;    
        }

        private void textAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura Invalida");
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio) || (raio <= 0))
            {
                MessageBox.Show("Raio Invalido");
                txtRaio.Focus();
            }
            else if (!double.TryParse(textAltura.Text, out altura) || (altura <= 0))
            {
                MessageBox.Show("Altura Invalida");
                textAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                textVolume.Text = volume.ToString("N2");
            }
        }
    }
}


    
