﻿namespace PCalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNumero1 = new TextBox();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            errorProvider3 = new ErrorProvider(components);
            txtNumero2 = new TextBox();
            txtResultado = new TextBox();
            btAdd = new Button();
            btsub = new Button();
            btmult = new Button();
            btDiv = new Button();
            btLimpar = new Button();
            btSair = new Button();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(33, 45);
            label1.Name = "label1";
            label1.Size = new Size(92, 25);
            label1.TabIndex = 0;
            label1.Text = "Numero 1";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(33, 116);
            label2.Name = "label2";
            label2.Size = new Size(92, 25);
            label2.TabIndex = 1;
            label2.Text = "Numero 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(33, 177);
            label3.Name = "label3";
            label3.Size = new Size(90, 25);
            label3.TabIndex = 2;
            label3.Text = "Resultado";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(165, 45);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(314, 31);
            txtNumero1.TabIndex = 3;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            errorProvider3.ContainerControl = this;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(165, 116);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(314, 31);
            txtNumero2.TabIndex = 4;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(165, 177);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(314, 31);
            txtResultado.TabIndex = 5;
            // 
            // btAdd
            // 
            btAdd.Location = new Point(49, 266);
            btAdd.Name = "btAdd";
            btAdd.Size = new Size(156, 110);
            btAdd.TabIndex = 6;
            btAdd.Text = "+";
            btAdd.UseVisualStyleBackColor = true;
            btAdd.Click += btAdd_Click;
            // 
            // btsub
            // 
            btsub.Location = new Point(244, 266);
            btsub.Name = "btsub";
            btsub.Size = new Size(156, 110);
            btsub.TabIndex = 7;
            btsub.Text = "-";
            btsub.UseVisualStyleBackColor = true;
            btsub.Click += btsub_Click;
            // 
            // btmult
            // 
            btmult.Location = new Point(443, 266);
            btmult.Name = "btmult";
            btmult.Size = new Size(156, 110);
            btmult.TabIndex = 8;
            btmult.Text = "*";
            btmult.UseVisualStyleBackColor = true;
            btmult.Click += btmult_Click;
            // 
            // btDiv
            // 
            btDiv.Location = new Point(630, 266);
            btDiv.Name = "btDiv";
            btDiv.Size = new Size(156, 110);
            btDiv.TabIndex = 9;
            btDiv.Text = "/";
            btDiv.UseVisualStyleBackColor = true;
            btDiv.Click += btDiv_Click;
            // 
            // btLimpar
            // 
            btLimpar.Location = new Point(571, 45);
            btLimpar.Name = "btLimpar";
            btLimpar.Size = new Size(163, 61);
            btLimpar.TabIndex = 10;
            btLimpar.Text = "Limpar";
            btLimpar.UseVisualStyleBackColor = true;
            btLimpar.Click += btLimpar_Click;
            // 
            // btSair
            // 
            btSair.Location = new Point(571, 147);
            btSair.Name = "btSair";
            btSair.Size = new Size(163, 61);
            btSair.TabIndex = 11;
            btSair.Text = "Sair";
            btSair.UseVisualStyleBackColor = true;
            btSair.Click += btSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btSair);
            Controls.Add(btLimpar);
            Controls.Add(btDiv);
            Controls.Add(btmult);
            Controls.Add(btsub);
            Controls.Add(btAdd);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNumero1;
        private ErrorProvider errorProvider1;
        private TextBox txtNumero2;
        private ErrorProvider errorProvider2;
        private ErrorProvider errorProvider3;
        private TextBox txtResultado;
        private Button btSair;
        private Button btLimpar;
        private Button btDiv;
        private Button btmult;
        private Button btsub;
        private Button btAdd;
    }
}
