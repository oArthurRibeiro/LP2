﻿namespace PIMC
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtAltura = new MaskedTextBox();
            txtPeso = new MaskedTextBox();
            txtIMC = new MaskedTextBox();
            buttonLimpar = new Button();
            buttonSair = new Button();
            buttonCalc = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(57, 91);
            label1.Name = "label1";
            label1.Size = new Size(59, 25);
            label1.TabIndex = 0;
            label1.Text = "Altura";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(57, 159);
            label2.Name = "label2";
            label2.Size = new Size(49, 25);
            label2.TabIndex = 1;
            label2.Text = "Peso";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(57, 245);
            label3.Name = "label3";
            label3.Size = new Size(44, 25);
            label3.TabIndex = 2;
            label3.Text = "IMC";
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(150, 88);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(253, 31);
            txtAltura.TabIndex = 1;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // txtPeso
            // 
            txtPeso.Location = new Point(150, 159);
            txtPeso.Name = "txtPeso";
            txtPeso.Size = new Size(253, 31);
            txtPeso.TabIndex = 2;
            txtPeso.Validated += txtPeso_Validated;
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(150, 245);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(253, 31);
            txtIMC.TabIndex = 3;
            // 
            // buttonLimpar
            // 
            buttonLimpar.Location = new Point(539, 88);
            buttonLimpar.Name = "buttonLimpar";
            buttonLimpar.Size = new Size(167, 84);
            buttonLimpar.TabIndex = 4;
            buttonLimpar.Text = "Limpar";
            buttonLimpar.UseVisualStyleBackColor = true;
            buttonLimpar.Click += buttonLimpar_Click;
            // 
            // buttonSair
            // 
            buttonSair.Location = new Point(539, 206);
            buttonSair.Name = "buttonSair";
            buttonSair.Size = new Size(167, 84);
            buttonSair.TabIndex = 5;
            buttonSair.Text = "Sair";
            buttonSair.UseVisualStyleBackColor = true;
            buttonSair.Click += buttonSair_Click;
            // 
            // buttonCalc
            // 
            buttonCalc.Location = new Point(57, 339);
            buttonCalc.Name = "buttonCalc";
            buttonCalc.Size = new Size(486, 69);
            buttonCalc.TabIndex = 6;
            buttonCalc.Text = "Calcular";
            buttonCalc.UseVisualStyleBackColor = true;
            buttonCalc.Click += buttonCalc_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonCalc);
            Controls.Add(buttonSair);
            Controls.Add(buttonLimpar);
            Controls.Add(txtIMC);
            Controls.Add(txtPeso);
            Controls.Add(txtAltura);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private MaskedTextBox txtAltura;
        private MaskedTextBox txtPeso;
        private MaskedTextBox txtIMC;
        private Button buttonLimpar;
        private Button buttonSair;
        private Button buttonCalc;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
    }
}
