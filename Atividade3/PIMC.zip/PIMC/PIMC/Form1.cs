namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                errorProvider1.SetError(txtAltura, "Valor Invalido");
                txtAltura.Focus();
            }
            else
                errorProvider1.SetError(txtAltura, "");
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out peso)|| peso <= 0)
            {
                errorProvider1.SetError(txtPeso, "Valor Invalido");
                txtPeso.Focus();
            }
            else
                errorProvider1.SetError(txtPeso, "");
        }


        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
                Close();
            }
        }

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            
                IMC = peso / (altura * altura);
                IMC = Math.Round(IMC, 1);
                txtIMC.Text = IMC.ToString("G");


            if (IMC < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (IMC <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (IMC <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (IMC <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else 
                MessageBox.Show("Obesidade Grave");
            
            
            
        }
    }
}