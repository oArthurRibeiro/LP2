﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtLadoA = new TextBox();
            txtLadoB = new TextBox();
            txtLadoC = new TextBox();
            buttonCalc = new Button();
            buttonLimpar = new Button();
            buttonSair = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            errorProvider3 = new ErrorProvider(components);
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 81);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 0;
            label1.Text = "Lado A";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 120);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 1;
            label2.Text = "Lado B";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 156);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 2;
            label3.Text = "Lado C";
            // 
            // txtLadoA
            // 
            txtLadoA.Location = new Point(106, 82);
            txtLadoA.Margin = new Padding(2, 2, 2, 2);
            txtLadoA.Name = "txtLadoA";
            txtLadoA.Size = new Size(252, 23);
            txtLadoA.TabIndex = 1;
            txtLadoA.Validated += txtLadoA_Validated;
            // 
            // txtLadoB
            // 
            txtLadoB.Location = new Point(106, 118);
            txtLadoB.Margin = new Padding(2, 2, 2, 2);
            txtLadoB.Name = "txtLadoB";
            txtLadoB.Size = new Size(252, 23);
            txtLadoB.TabIndex = 2;
            txtLadoB.Validated += txtLadoB_Validated;
            // 
            // txtLadoC
            // 
            txtLadoC.Location = new Point(106, 154);
            txtLadoC.Margin = new Padding(2, 2, 2, 2);
            txtLadoC.Name = "txtLadoC";
            txtLadoC.Size = new Size(252, 23);
            txtLadoC.TabIndex = 5;
            txtLadoC.Validated += txtLadoC_Validated;
            // 
            // buttonCalc
            // 
            buttonCalc.Location = new Point(383, 34);
            buttonCalc.Margin = new Padding(2, 2, 2, 2);
            buttonCalc.Name = "buttonCalc";
            buttonCalc.Size = new Size(109, 44);
            buttonCalc.TabIndex = 6;
            buttonCalc.Text = "Calcular";
            buttonCalc.UseVisualStyleBackColor = true;
            buttonCalc.Click += buttonCalc_Click;
            // 
            // buttonLimpar
            // 
            buttonLimpar.Location = new Point(383, 102);
            buttonLimpar.Margin = new Padding(2, 2, 2, 2);
            buttonLimpar.Name = "buttonLimpar";
            buttonLimpar.Size = new Size(109, 44);
            buttonLimpar.TabIndex = 7;
            buttonLimpar.Text = "Limpar";
            buttonLimpar.UseVisualStyleBackColor = true;
            buttonLimpar.Click += buttonLimpar_Click;
            // 
            // buttonSair
            // 
            buttonSair.Location = new Point(383, 178);
            buttonSair.Margin = new Padding(2, 2, 2, 2);
            buttonSair.Name = "buttonSair";
            buttonSair.Size = new Size(109, 44);
            buttonSair.TabIndex = 8;
            buttonSair.Text = "Sair";
            buttonSair.UseVisualStyleBackColor = true;
            buttonSair.Click += buttonSair_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            errorProvider3.ContainerControl = this;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(168, 37);
            label4.Name = "label4";
            label4.Size = new Size(126, 30);
            label4.TabIndex = 9;
            label4.Text = "TRIANGULO";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(label4);
            Controls.Add(buttonSair);
            Controls.Add(buttonLimpar);
            Controls.Add(buttonCalc);
            Controls.Add(txtLadoC);
            Controls.Add(txtLadoB);
            Controls.Add(txtLadoA);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(2, 2, 2, 2);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtLadoA;
        private TextBox txtLadoB;
        private TextBox txtLadoC;
        private Button buttonCalc;
        private Button buttonLimpar;
        private Button buttonSair;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
        private ErrorProvider errorProvider3;
        private Label label4;
    }
}
