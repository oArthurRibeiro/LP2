namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA) || ladoA <= 0)
            {
                errorProvider1.SetError(txtLadoA, "Valor Invalido");
                txtLadoA.Focus();
            }
            else
                errorProvider1.SetError(txtLadoA, "");
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB) || ladoB <= 0)
            {
                errorProvider2.SetError(txtLadoB, "Valor Invalido");
                txtLadoB.Focus();
            }
            else
                errorProvider2.SetError(txtLadoA, "");
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC) || ladoC <= 0)
            {
                errorProvider1.SetError(txtLadoC, "Valor Invalido");
                txtLadoC.Focus();
            }
            else
                errorProvider3.SetError(txtLadoC, "");
        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
                Close();
            }
        }

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            if (ladoA < ladoB + ladoC && ladoA > Math.Abs(ladoB - ladoC) && ladoB < ladoA + ladoC)
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Triangulo Equilatero");
                }
                else if (ladoA == ladoB && ladoA > ladoC)
                {
                    MessageBox.Show("Triangulo Isoseles");
                }
                else if (ladoC < ladoA + ladoB)
                {
                    MessageBox.Show("Triangulo Escaleno");
                }
            }
        }
    }
}

