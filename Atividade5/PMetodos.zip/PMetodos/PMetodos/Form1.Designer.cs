﻿namespace PMetodos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            FrmExer1 = new MenuStrip();
            toolStripMenuItem1 = new ToolStripMenuItem();
            toolStripTextBox1 = new ToolStripMenuItem();
            toolStripTextBox3 = new ToolStripTextBox();
            toolStripTextBox2 = new ToolStripMenuItem();
            ctrlVToolStripMenuItem = new ToolStripTextBox();
            toolStripMenuItem2 = new ToolStripMenuItem();
            toolStripMenuItem3 = new ToolStripMenuItem();
            toolStripMenuItem4 = new ToolStripMenuItem();
            toolStripMenuItem5 = new ToolStripMenuItem();
            toolStripMenuItem6 = new ToolStripMenuItem();
            contextMenuStrip1 = new ContextMenuStrip(components);
            FrmExer1.SuspendLayout();
            SuspendLayout();
            // 
            // FrmExer1
            // 
            FrmExer1.ImageScalingSize = new Size(24, 24);
            FrmExer1.Items.AddRange(new ToolStripItem[] { toolStripMenuItem1, toolStripMenuItem2, toolStripMenuItem3, toolStripMenuItem4, toolStripMenuItem5, toolStripMenuItem6 });
            FrmExer1.Location = new Point(0, 0);
            FrmExer1.Name = "FrmExer1";
            FrmExer1.Padding = new Padding(4, 1, 0, 1);
            FrmExer1.Size = new Size(560, 24);
            FrmExer1.TabIndex = 0;
            FrmExer1.Text = "Exercicio 1";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { toolStripTextBox1, toolStripTextBox2 });
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(75, 22);
            toolStripMenuItem1.Text = "Exercicio 1";
            // 
            // toolStripTextBox1
            // 
            toolStripTextBox1.DropDownItems.AddRange(new ToolStripItem[] { toolStripTextBox3 });
            toolStripTextBox1.Name = "toolStripTextBox1";
            toolStripTextBox1.Size = new Size(109, 22);
            toolStripTextBox1.Text = "Copiar";
            // 
            // toolStripTextBox3
            // 
            toolStripTextBox3.Name = "toolStripTextBox3";
            toolStripTextBox3.Size = new Size(100, 23);
            toolStripTextBox3.Text = "Ctrl + C";
            // 
            // toolStripTextBox2
            // 
            toolStripTextBox2.DropDownItems.AddRange(new ToolStripItem[] { ctrlVToolStripMenuItem });
            toolStripTextBox2.Name = "toolStripTextBox2";
            toolStripTextBox2.Size = new Size(109, 22);
            toolStripTextBox2.Text = "Colar";
            // 
            // ctrlVToolStripMenuItem
            // 
            ctrlVToolStripMenuItem.Name = "ctrlVToolStripMenuItem";
            ctrlVToolStripMenuItem.Size = new Size(180, 23);
            ctrlVToolStripMenuItem.Text = "Ctrl + V";
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.ForeColor = Color.Black;
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.ShortcutKeys = Keys.Alt | Keys.D2;
            toolStripMenuItem2.Size = new Size(75, 22);
            toolStripMenuItem2.Text = "Exercicio 2";
            toolStripMenuItem2.Click += toolStripMenuItem2_Click;
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.ShortcutKeys = Keys.Alt | Keys.D3;
            toolStripMenuItem3.Size = new Size(75, 22);
            toolStripMenuItem3.Text = "Exercicio 3";
            toolStripMenuItem3.Click += toolStripMenuItem3_Click;
            // 
            // toolStripMenuItem4
            // 
            toolStripMenuItem4.Name = "toolStripMenuItem4";
            toolStripMenuItem4.ShortcutKeys = Keys.Alt | Keys.D4;
            toolStripMenuItem4.Size = new Size(75, 22);
            toolStripMenuItem4.Text = "Exercicio 4";
            toolStripMenuItem4.Click += toolStripMenuItem4_Click_1;
            // 
            // toolStripMenuItem5
            // 
            toolStripMenuItem5.Name = "toolStripMenuItem5";
            toolStripMenuItem5.ShortcutKeys = Keys.Alt | Keys.D5;
            toolStripMenuItem5.Size = new Size(75, 22);
            toolStripMenuItem5.Text = "Exercicio 5";
            toolStripMenuItem5.Click += toolStripMenuItem5_Click;
            // 
            // toolStripMenuItem6
            // 
            toolStripMenuItem6.Name = "toolStripMenuItem6";
            toolStripMenuItem6.ShortcutKeys = Keys.F4;
            toolStripMenuItem6.Size = new Size(38, 22);
            toolStripMenuItem6.Text = "Sair";
            toolStripMenuItem6.Click += toolStripMenuItem6_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            ContextMenuStrip = contextMenuStrip1;
            Controls.Add(FrmExer1);
            IsMdiContainer = true;
            MainMenuStrip = FrmExer1;
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            FrmExer1.ResumeLayout(false);
            FrmExer1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip FrmExer1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem toolStripMenuItem5;
        private ToolStripMenuItem toolStripMenuItem6;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem toolStripTextBox1;
        private ToolStripTextBox toolStripTextBox3;
        private ToolStripMenuItem toolStripTextBox2;
        private ToolStripTextBox ctrlVToolStripMenuItem;
    }
}
