namespace PMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                Application.OpenForms["FrmExercio3"].BringToFront();


            }
            else
            {


                FrmExercicio3 frm3 = new FrmExercicio3();

                frm3.MdiParent = this;
                frm3.WindowState = FormWindowState.Maximized;
                frm3.Show();
            }


        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                Application.OpenForms["frmExercio2"].BringToFront();
            }
            else
            {
                frmExercicio2 frm2 = new frmExercicio2();

                frm2.MdiParent = this;
                frm2.WindowState = FormWindowState.Maximized;
                frm2.Show();
            }
        }




        private void toolStripMenuItem4_Click_1(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio_4>().Count() > 0)
            {
                Application.OpenForms["FrmExercio_4"].BringToFront();
            }
            else
            {
                FrmExercicio_4 frm4 = new FrmExercicio_4();

                frm4.MdiParent = this;
                frm4.WindowState = FormWindowState.Maximized;
                frm4.Show();
            }
        }
        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExer5>().Count() > 0)
            {
                Application.OpenForms["FrmExer5"].BringToFront();
            }
            else
            {
                FrmExer5 frm5 = new FrmExer5();

                frm5.MdiParent = this;
                frm5.WindowState = FormWindowState.Maximized;
                frm5.Show();
            }
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}



