﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FrmExer5 : Form
    {
        public FrmExer5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int numero1, numero2;
          
            if (!int.TryParse(txtNumero1.Text, out  numero1) ||
                    !int.TryParse(txtNumero2.Text, out  numero2))
            {
                MessageBox.Show("Valor digitado Invalido");

                return;
            }
            if (numero1 >= numero2)
            {
                MessageBox.Show("o 1º numero deve ser maior que o 2º");
            }
            Random Sorteio = new Random();

            int escolhido = Sorteio.Next(numero1, numero2 + 1);

            MessageBox.Show($"Numero sorteado: {escolhido}");
        }
    }
}
