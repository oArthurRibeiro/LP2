﻿namespace PMetodos
{
    partial class FrmExercicio_4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rtxtFrase = new RichTextBox();
            btnNumber = new Button();
            btnBranco = new Button();
            btnAlfabetico = new Button();
            SuspendLayout();
            // 
            // rtxtFrase
            // 
            rtxtFrase.Location = new Point(28, 68);
            rtxtFrase.Name = "rtxtFrase";
            rtxtFrase.Size = new Size(446, 306);
            rtxtFrase.TabIndex = 0;
            rtxtFrase.Text = "";
            // 
            // btnNumber
            // 
            btnNumber.Location = new Point(520, 68);
            btnNumber.Name = "btnNumber";
            btnNumber.Size = new Size(189, 78);
            btnNumber.TabIndex = 1;
            btnNumber.Text = "Cont Numerico";
            btnNumber.UseVisualStyleBackColor = true;
            btnNumber.Click += btnNumber_Click;
            // 
            // btnBranco
            // 
            btnBranco.Location = new Point(520, 187);
            btnBranco.Name = "btnBranco";
            btnBranco.Size = new Size(189, 78);
            btnBranco.TabIndex = 2;
            btnBranco.Text = "1º Branco";
            btnBranco.UseVisualStyleBackColor = true;
            btnBranco.Click += btnBranco_Click;
            // 
            // btnAlfabetico
            // 
            btnAlfabetico.Location = new Point(520, 310);
            btnAlfabetico.Name = "btnAlfabetico";
            btnAlfabetico.Size = new Size(189, 78);
            btnAlfabetico.TabIndex = 3;
            btnAlfabetico.Text = "Cont Alfabetico";
            btnAlfabetico.UseVisualStyleBackColor = true;
            btnAlfabetico.Click += btnAlfabetico_Click;
            // 
            // FrmExercicio_4
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAlfabetico);
            Controls.Add(btnBranco);
            Controls.Add(btnNumber);
            Controls.Add(rtxtFrase);
            Name = "FrmExercicio_4";
            Text = "FrmExercicio_4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rtxtFrase;
        private Button btnNumber;
        private Button btnBranco;
        private Button btnAlfabetico;
    }
}