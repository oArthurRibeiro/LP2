﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class FrmExercicio_4 : Form
    {
        public FrmExercicio_4()
        {
            InitializeComponent();
        }

        private void btnNumber_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contNum = 0;

            while (contador < rtxtFrase.Text.Length)
            {
                if (char.IsNumber(rtxtFrase.Text[contador]))
                {
                    contNum++;
                }
                contador++;
            }
            MessageBox.Show($"o texto tem {contNum} numeros");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1º caracter branco é {i+1}");
                    break;
                }

            }
        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetra} letras");
        }
    }
}