﻿namespace PMetodos
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            btnRemove = new Button();
            btnInvert = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(57, 98);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(310, 31);
            txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(57, 236);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(310, 31);
            txtPalavra2.TabIndex = 1;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(477, 73);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(167, 81);
            btnRemove.TabIndex = 2;
            btnRemove.Text = "Remover";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnInvert
            // 
            btnInvert.Location = new Point(477, 211);
            btnInvert.Name = "btnInvert";
            btnInvert.Size = new Size(167, 81);
            btnInvert.TabIndex = 3;
            btnInvert.Text = "Inverter";
            btnInvert.UseVisualStyleBackColor = true;
            btnInvert.Click += btnInvert_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(65, 49);
            label1.Name = "label1";
            label1.Size = new Size(102, 25);
            label1.TabIndex = 4;
            label1.Text = "PALAVRA 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(65, 195);
            label2.Name = "label2";
            label2.Size = new Size(102, 25);
            label2.TabIndex = 5;
            label2.Text = "PALAVRA 2";
            // 
            // FrmExercicio3
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnInvert);
            Controls.Add(btnRemove);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "FrmExercicio3";
            Text = "FrmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Button btnRemove;
        private Button btnInvert;
        private Label label1;
        private Label label2;
    }
}