﻿namespace PMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            btnCompare = new Button();
            btnConcatena = new Button();
            btnInsert = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(64, 56);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 0;
            label1.Text = "Palavra 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(64, 103);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 1;
            label2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(134, 56);
            txtPalavra1.Margin = new Padding(2);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(172, 23);
            txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(134, 103);
            txtPalavra2.Margin = new Padding(2);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(172, 23);
            txtPalavra2.TabIndex = 3;
            // 
            // btnCompare
            // 
            btnCompare.Location = new Point(57, 165);
            btnCompare.Margin = new Padding(2);
            btnCompare.Name = "btnCompare";
            btnCompare.Size = new Size(127, 58);
            btnCompare.TabIndex = 4;
            btnCompare.Text = "Comparar";
            btnCompare.UseVisualStyleBackColor = true;
            btnCompare.Click += button1_Click;
            // 
            // btnConcatena
            // 
            btnConcatena.Location = new Point(223, 165);
            btnConcatena.Margin = new Padding(2);
            btnConcatena.Name = "btnConcatena";
            btnConcatena.Size = new Size(127, 58);
            btnConcatena.TabIndex = 5;
            btnConcatena.Text = "Contatenar";
            btnConcatena.UseVisualStyleBackColor = true;
            btnConcatena.Click += btnConcatena_Click;
            // 
            // btnInsert
            // 
            btnInsert.Location = new Point(398, 165);
            btnInsert.Margin = new Padding(2);
            btnInsert.Name = "btnInsert";
            btnInsert.Size = new Size(127, 58);
            btnInsert.TabIndex = 6;
            btnInsert.Text = "Inserir (*)";
            btnInsert.UseVisualStyleBackColor = true;
            btnInsert.Click += btnInsert_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(btnInsert);
            Controls.Add(btnConcatena);
            Controls.Add(btnCompare);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(2);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Button btnCompare;
        private Button btnConcatena;
        private Button btnInsert;
    }
}