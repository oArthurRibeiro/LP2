﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void btnExer1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}º número", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor invalido");
                    i--;
                }
                Array.Reverse(vetor);
                aux = " ";
                aux = string.Join("\n", vetor);
                MessageBox.Show(aux);
            }
        }

        private void btnExer2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otavio", "Marcelo", "Pedro", "Thais" };
            lista.Remove("Otavio");
            string aux = " ";
            foreach (string nome in lista)
            {
                aux += nome + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnESC_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
                Close();
            }
        }

        private void btnExer3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux = " ";
            double media = 0;
            string saida = " ";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!(double.TryParse(aux, out notas[i, j])) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado Invalido");
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                saida += ($"Aluno: {i + 1} Media {media / 3}\n");
                media = 0;
            }
            MessageBox.Show(saida);
        }

        private void btnExer5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms["Frmexercicio5"].BringToFront();


            }
            else
            {


                FrmExercicio5 frm5 = new FrmExercicio5();
                frm5.Show();
            }
        }


        private void btnExer4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form4>().Count() > 0)
            {
                Application.OpenForms["Form4"].BringToFront();


            }
            else
            {


                Form4 frm4 = new Form4();
                frm4.Show();
            }
        }
    }
}

