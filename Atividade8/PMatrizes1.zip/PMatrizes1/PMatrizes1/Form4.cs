﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PMatrizes1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[3];
            int[] tamanho = new int[3];

            for (int i = 0; i < 3; i++)
            {
                string nome;
                do
                {
                    nome = Interaction.InputBox($"Digite o nome da pessoa {i + 1}:", "Entrada de dados");


                } while (string.IsNullOrWhiteSpace(nome));
                nomes[i] = nome;
                string semespaço = nome.Replace(" ", "");
                tamanho[i] = semespaço.Length;
            }
            for (int i = 0; i < 3; i++) {
                listBox1.Items.Add($"o nome {nomes} tem {tamanho} caracteres");
            }
        }
    }
}