﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PMatrizes1
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {

            listBox1.Items.Clear();


            int ultimoDigitoRA = 6;
            int N = (ultimoDigitoRA == 0) ? 2 : ultimoDigitoRA + 1;


            char[] gabarito = { 'A', 'C', 'B', 'D', 'A', 'E', 'C', 'B', 'D', 'A' };


            char[,] respostas = new char[N, 10];

            for (int i = 0; i < N; i++)
            {
                int acertos = 0;

                for (int j = 0; j < 10; j++)
                {
                    char resp;
                    do
                    {
                        string entrada = Interaction.InputBox(
                            $"Aluno {i + 1} - Questão {j + 1} (A/B/C/D/E):",
                            "Resposta da Prova"
                        ).ToUpper().Trim();

                        resp = (string.IsNullOrEmpty(entrada)) ? ' ' : entrada[0];
                    }
                    while ("ABCDE".IndexOf(resp) == -1); // repete até ser válido

                    respostas[i, j] = resp;

                    if (resp == gabarito[j])
                        acertos++;
                }

                listBox1.Items.Add($"Aluno {i + 1} acertou {acertos} questões.");
            }
        }
    }
}
