﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[5, 3];
            string aux = " ";
            double media = 0;
            string saida = " ";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota do Professor {j + 1} do Aluno {i + 1}", "Entrada das notas:");
                    if (!(double.TryParse(aux, out notas[i, j])) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("NOTA INVALIDA!");
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                    saida += ($"Aluno {i + 1} => Nota Professor {j + 1}: {notas[i,j]} /  NotaProfessor {j + 2}: {notas[i, j]} / Nota Professor {j + 3}: {notas[i, j]} //  Media {media / 3}\n");
                    media = 0;
                }

            }
            listBoxNotas.Items.Add(saida);

            /*double mediaGeral = 0;  

            for (int i = 0;i < 5;i++)
                mediaGeral = notas[i] / 5;
                

            MessageBox.Show(mediaGeral);*/
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxNotas.Items.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
